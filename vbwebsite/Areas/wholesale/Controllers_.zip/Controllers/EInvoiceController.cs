﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using TaxProEInvoice.API;
using vb.Data;
using vb.Data.ViewModel;
using vb.Service;
using ZXing;

namespace vbwebsite.Areas.wholesale.Controllers
{
    public class EInvoiceController : Controller
    {
        private static object Lock = new object();
        private OrderServices _orderService = new OrderServices();
        eInvoiceSession eInvSession = new eInvoiceSession(false, false);

        //public EInvoiceController()
        //{
        //    _EWayservice = eWayservice;
        //}
        //
        // GET: /wholesale/EInvoice/
        public ActionResult Index()
        {
            SaveSettings();
            SaveLoginDetails();
            return View();
        }

        public void SaveSettings()
        {
            eInvSession.eInvApiSetting = new eInvoiceAPISetting();
            eInvSession.eInvApiSetting.GSPName = "TaxPro_Sandbox";
            eInvSession.eInvApiSetting.AspUserId = "1655841121";
            eInvSession.eInvApiSetting.AspPassword = "M@tizS0ft";
            eInvSession.eInvApiSetting.client_id = "";
            eInvSession.eInvApiSetting.client_secret = "";
            eInvSession.eInvApiSetting.AuthUrl = "http://testapi.taxprogsp.co.in/eivital/v1.03";
            eInvSession.eInvApiSetting.BaseUrl = "http://testapi.taxprogsp.co.in/eicore/v1.03";
            eInvSession.eInvApiSetting.EwbByIRN = "http://testapi.taxprogsp.co.in/eiewb/v1.03";
            eInvSession.eInvApiSetting.CancelEwbUrl = "http://testapi.taxprogsp.co.in/v1.03";
            Shared.SaveAPISetting(eInvSession.eInvApiSetting);
        }

        public void SaveLoginDetails()
        {
            eInvSession.eInvApiLoginDetails = new eInvoiceAPILoginDetails();
            eInvSession.eInvApiLoginDetails.UserName = ConfigurationManager.AppSettings["UserName"];
            eInvSession.eInvApiLoginDetails.Password = ConfigurationManager.AppSettings["Password"];
            eInvSession.eInvApiLoginDetails.GSTIN = "34AACCC1596Q002";
            eInvSession.eInvApiLoginDetails.AppKey = "RvCyJnJZDGGd3EaxDyK+SAUtkAS/GqO4CsH+ScjykDU=";
            eInvSession.eInvApiLoginDetails.AuthToken = GetAuthToken();
            eInvSession.eInvApiLoginDetails.Sek = "Nevbc2jtP2UXjsfG9nkrfJA9AqDZTCGcgd8R5TSz5XI=";
            eInvSession.eInvApiLoginDetails.E_InvoiceTokenExp = Convert.ToDateTime("3/23/2021 11:57:40 AM");
            Shared.SaveAPILoginDetails(eInvSession.eInvApiLoginDetails);
        }

        public string GetAuthToken()
        {
            string AuthTokenResponse = string.Empty;
            TxnRespWithObj<eInvoiceSession> txnRespWithObj = Task.Run(() => eInvoiceAPI.GetAuthTokenAsync(eInvSession)).Result;
            // here store in DB
            return AuthTokenResponse;
        }

        public EInvoice GenIRN(OrderQtyInvoiceList orderData, List<OrderQtyInvoiceList> lstData)
        {
            EInvoice eInvoice = new EInvoice();
            SaveSettings();
            SaveLoginDetails();
            Int64 orderId = 0;
            double totalAmount = 0;
            double totalTaxAmount = 0;
            double totalIGSTTaxAmount = 0;
            string invoiceNumber = string.Empty;
            invoiceNumber = lstData[0].InvoiceNumber;
            orderId = lstData[0].OrderID;


            ReqPlGenIRN reqPlGenIRN = new ReqPlGenIRN();
            reqPlGenIRN.Version = "1.1";
            reqPlGenIRN.TranDtls = new ReqPlGenIRN.TranDetails();
            reqPlGenIRN.TranDtls.TaxSch = "GST";
            reqPlGenIRN.TranDtls.SupTyp = "B2B";
            reqPlGenIRN.DocDtls = new ReqPlGenIRN.DocSetails();
            reqPlGenIRN.DocDtls.Typ = "INV";  //lstData.DocType;
            reqPlGenIRN.DocDtls.No = lstData[0].InvoiceNumber;
            reqPlGenIRN.DocDtls.Dt = lstData[0].DocDate;
            reqPlGenIRN.SellerDtls = new ReqPlGenIRN.SellerDetails();
            reqPlGenIRN.SellerDtls.Gstin = "34AACCC1596Q002";
            reqPlGenIRN.SellerDtls.LglNm = orderData.From_Name;
            reqPlGenIRN.SellerDtls.TrdNm = orderData.From_Name;
            reqPlGenIRN.SellerDtls.Addr1 = orderData.From_Address1;
            reqPlGenIRN.SellerDtls.Addr2 = null;
            reqPlGenIRN.SellerDtls.Loc = orderData.From_Place;
            reqPlGenIRN.SellerDtls.Pin = orderData.From_PinCode;
            reqPlGenIRN.SellerDtls.Stcd = "34";
            reqPlGenIRN.SellerDtls.Ph = null;
            reqPlGenIRN.SellerDtls.Em = null;
            reqPlGenIRN.BuyerDtls = new ReqPlGenIRN.BuyerDetails();
            reqPlGenIRN.BuyerDtls.Gstin = orderData.TaxNo;
            reqPlGenIRN.BuyerDtls.LglNm = orderData.CustomerName;
            reqPlGenIRN.BuyerDtls.TrdNm = null;
            reqPlGenIRN.BuyerDtls.Pos = orderData.StateCode;
            reqPlGenIRN.BuyerDtls.Addr1 = "Delivery Add";//orderData.DeliveryTo;
            reqPlGenIRN.BuyerDtls.Addr2 = null;
            reqPlGenIRN.BuyerDtls.Loc = orderData.State;
            reqPlGenIRN.BuyerDtls.Pin = Convert.ToInt32(orderData.PinCode);
            reqPlGenIRN.BuyerDtls.Stcd = orderData.StateCode;
            reqPlGenIRN.BuyerDtls.Ph = null;
            reqPlGenIRN.BuyerDtls.Em = null;
            reqPlGenIRN.DispDtls = new ReqPlGenIRN.DispatchedDetails();
            reqPlGenIRN.DispDtls.Nm = orderData.From_Name;
            reqPlGenIRN.DispDtls.Addr1 = orderData.From_Address1;
            reqPlGenIRN.DispDtls.Addr2 = null;
            reqPlGenIRN.DispDtls.Loc = orderData.From_Place;
            reqPlGenIRN.DispDtls.Pin = orderData.From_PinCode;
            reqPlGenIRN.DispDtls.Stcd = "34";
            reqPlGenIRN.ShipDtls = new ReqPlGenIRN.ShippedDetails();
            reqPlGenIRN.ShipDtls.Gstin = orderData.TaxNo;
            reqPlGenIRN.ShipDtls.LglNm = orderData.CustomerName;
            reqPlGenIRN.ShipDtls.TrdNm = null;
            reqPlGenIRN.ShipDtls.Addr1 = "Delivery Add";// orderData.DeliveryTo;
            reqPlGenIRN.ShipDtls.Addr2 = null;
            reqPlGenIRN.ShipDtls.Loc = orderData.State;
            reqPlGenIRN.ShipDtls.Pin = Convert.ToInt32(orderData.PinCode);
            reqPlGenIRN.ShipDtls.Stcd = orderData.StateCode;
            reqPlGenIRN.ItemList = new List<ReqPlGenIRN.ItmList>();
            ReqPlGenIRN.ItmList itm = new ReqPlGenIRN.ItmList();
            int rowNumber = 2;
            foreach (var data in lstData)
            {
                if (data.ProductName != "")
                {
                    itm = new ReqPlGenIRN.ItmList();
                    itm.SlNo = rowNumber.ToString(); //data.SerialNumber.ToString();
                    itm.IsServc = "N";
                    itm.PrdDesc = null;
                    itm.HsnCd = data.HSNNumber;
                    itm.BchDtls = null;
                    itm.Qty = Convert.ToDouble(data.Quantity);
                    itm.Unit = "NOS";  //data.UnitName;
                    itm.UnitPrice = Convert.ToDouble(data.SaleRate);
                    itm.TotAmt = Convert.ToDouble(data.Total);
                    itm.Discount = Convert.ToDouble(data.BillDiscount);
                    itm.AssAmt = Convert.ToDouble(data.Total);
                    if (data.TaxName == "IGST")
                        itm.GstRt = Convert.ToDouble(data.IGSTTaxRate);
                    else
                        itm.GstRt = Convert.ToDouble(data.SGSTTaxRate + data.CGSTTaxRate);
                    itm.SgstAmt = Convert.ToDouble(data.SGSTAmount);
                    itm.IgstAmt = Convert.ToDouble(data.IGSTAmount);
                    itm.CgstAmt = Convert.ToDouble(data.CGSTAmount);
                    itm.CesRt = Convert.ToDouble(data.CESSTaxRate);
                    itm.CesAmt = Convert.ToDouble(data.CESSAmount);
                    itm.CesNonAdvlAmt = Convert.ToDouble(data.Cess_Non_Advol_Amount);
                    itm.StateCesRt = 0.0;
                    itm.StateCesAmt = 0.0;
                    itm.StateCesNonAdvlAmt = 0.0;
                    itm.OthChrg = 0.0;
                    itm.TotItemVal = Math.Round(Convert.ToDouble(data.TotalAmount), 2);
                    totalAmount += itm.TotAmt;
                    itm.AttribDtls = null;
                    if (data.TaxName == "IGST")
                    {
                        totalIGSTTaxAmount += Math.Round(Convert.ToDouble(data.IGSTAmount), 2);
                    }
                    else
                    {
                        totalTaxAmount += Math.Round((Convert.ToDouble(data.SGSTAmount) + Convert.ToDouble(data.CGSTAmount)), 2);
                    }
                    reqPlGenIRN.ItemList.Add(itm);
                    rowNumber += 1;
                }
            }
            reqPlGenIRN.PayDtls = null;
            reqPlGenIRN.RefDtls = null;
            reqPlGenIRN.AddlDocDtls = null;
            reqPlGenIRN.ExpDtls = null;
            reqPlGenIRN.EwbDtls = null;
            reqPlGenIRN.ValDtls = new ReqPlGenIRN.ValDetails();
            reqPlGenIRN.ValDtls.AssVal = totalAmount;
            reqPlGenIRN.ValDtls.CgstVal = Math.Round((totalTaxAmount / 2), 2);
            reqPlGenIRN.ValDtls.SgstVal = Math.Round((totalTaxAmount / 2), 2);
            reqPlGenIRN.ValDtls.IgstVal = Math.Round(totalIGSTTaxAmount, 2);
            reqPlGenIRN.ValDtls.CesVal = Convert.ToDouble(lstData[0].CESSAmount);
            reqPlGenIRN.ValDtls.StCesVal = 0.0;
            reqPlGenIRN.ValDtls.RndOffAmt = 0.0;
            reqPlGenIRN.ValDtls.TotInvVal = Math.Round((totalTaxAmount + totalIGSTTaxAmount + totalAmount), 2);


            string name = invoiceNumber.Replace('/', '-');
            //string path = Path.Combine(Server.MapPath("~/QRCode/") + name);


            string result = "";
            string pas = JsonConvert.SerializeObject(reqPlGenIRN);
            TxnRespWithObj<RespPlGenIRN> txnRespWithObj = Task.Run(() => eInvoiceAPI.GenIRNAsync(eInvSession, pas, 250)).Result;

            //Console.Write(result);

            RespPlGenIRN respPlGenIRN = txnRespWithObj.RespObj;
            string ErrorCodes = "";
            string ErrorDesc = "";
            //rtbResponce.Text = "";
            if (txnRespWithObj.IsSuccess)
            {
                //Process the Response here
                //For DEMO, just showing the searilized Response Object in text box
                result = JsonConvert.SerializeObject(respPlGenIRN.ExtractedSignedQrCode);

                string path = "";
                //@"F:\VirakiBrothers\VirakiBrothers\Source\vbwebsite\QRCode\";



              


                //if (System.Configuration.ConfigurationManager.AppSettings["HostingEnvironment"].ToString() == HostingEnvironment.localhost.ToString())
                //{
                //    path = "http://" + System.Web.HttpContext.Current.Request.Url.Host + ":6551/QRCode/";
                //}
                //else if (System.Configuration.ConfigurationManager.AppSettings["HostingEnvironment"].ToString() == HostingEnvironment.staging.ToString())
                //{
                //    path = "http://" + System.Web.HttpContext.Current.Request.Url.Host + "/QRCode/";
                //}
                //else
                //{
                //    path = "https://" + System.Web.HttpContext.Current.Request.Url.Host + "/QRCode/";
                //}

                //path = path.Replace('/', '\\');

                path = path + name + ".png";


                string DestinationFile = Path.Combine(System.Web.HttpContext.Current.Server.MapPath("~/QRCode/") + name + ".png");



                //string name = path + reqPlGenIRN.DocDtls.No + ".png";
                respPlGenIRN.QrCodeImage.Save(DestinationFile);


                var barcodeWriter = new BarcodeWriter();
                barcodeWriter.Format = BarcodeFormat.QR_CODE;

                var res = barcodeWriter.Write(result);

                var barcodeBitmap = new Bitmap(res);
                using (MemoryStream memory = new MemoryStream())
                {
                    using (FileStream fs = new FileStream(DestinationFile, FileMode.Create, FileAccess.ReadWrite))
                    {
                        barcodeBitmap.Save(memory, ImageFormat.Png);
                        byte[] bytes = memory.ToArray();
                        fs.Write(bytes, 0, bytes.Length);
                    }
                }

                var barcodeReader = new BarcodeReader();

                var resultDecode = barcodeReader.Decode(new Bitmap(DestinationFile));
                if (resultDecode != null)
                {
                    respPlGenIRN.ExtractedSignedQrCode = JsonConvert.DeserializeObject<RespGenIRNQrCodeData>(resultDecode.ToString());
                    respPlGenIRN.SignedQRCode = resultDecode.Text;
                }


                //Store respPlGenIRN (manditory - AckDate and SignedInvoice) to verify signed invoice
                //below code is to show how to verify signed invoice
                respPlGenIRN.QrCodeImage = null;
                //TxnRespWithObj<VerifyRespPl> txnRespWithObj1 = Task.Run(() => eInvoiceAPI.VerifySignedInvoice(eInvSession, respPlGenIRN)).Result;


                //VerifyRespPl verifyRespPl = new VerifyRespPl();
                //if (txnRespWithObj.IsSuccess)
                //{
                //    verifyRespPl.IsVerified = txnRespWithObj1.RespObj.IsVerified;
                //    verifyRespPl.JwtIssuerIRP = txnRespWithObj1.RespObj.JwtIssuerIRP;
                //    verifyRespPl.VerifiedWithCertificateEffectiveFrom = txnRespWithObj1.RespObj.VerifiedWithCertificateEffectiveFrom;
                //    verifyRespPl.CertificateName = txnRespWithObj1.RespObj.CertificateName;
                //    verifyRespPl.CertStartDate = txnRespWithObj1.RespObj.CertStartDate;
                //    verifyRespPl.CertExpiryDate = txnRespWithObj1.RespObj.CertExpiryDate;
                //}

                eInvoice.OrderId = orderId;
                eInvoice.InvoiceNumber = invoiceNumber;
                eInvoice.IRN = respPlGenIRN.Irn;
                eInvoice.QRCode = name + ".png";
                eInvoice.AckDt = Convert.ToDateTime(respPlGenIRN.AckDt);
                eInvoice.AckNo = Convert.ToInt64(respPlGenIRN.AckNo);
                _orderService.AddEInvoice(eInvoice);

            }
            else
            {
                //Error has occured
                //Display TxnOutCome in text box - process or show msg to user

                //Process error codes
                if (txnRespWithObj.ErrorDetails != null)
                {
                    foreach (RespErrDetailsPl errPl in txnRespWithObj.ErrorDetails)
                    {
                        //Process errPl item here
                        ErrorCodes += errPl.ErrorCode + ",";
                        ErrorDesc += errPl.ErrorCode + ": " + errPl.ErrorMessage + Environment.NewLine;
                        result = ErrorDesc;
                    }
                }

                //Process InfoDetails here
                RespInfoDtlsPl respInfoDtlsPl = new RespInfoDtlsPl();
                //Serialize Desc object from InfoDtls as per InfCd
                if (txnRespWithObj.InfoDetails != null)
                {
                    foreach (RespInfoDtlsPl infoPl in txnRespWithObj.InfoDetails)
                    {
                        var strDupIrnPl = JsonConvert.SerializeObject(infoPl.Desc);   //Convert object type to json string
                        switch (infoPl.InfCd)
                        {
                            case "DUPIRN":
                                DupIrnPl dupIrnPl = JsonConvert.DeserializeObject<DupIrnPl>(strDupIrnPl);
                                break;
                            case "EWBERR":
                                List<EwbErrPl> ewbErrPl = JsonConvert.DeserializeObject<List<EwbErrPl>>(strDupIrnPl);
                                break;
                            case "ADDNLNFO":
                                //Deserialize infoPl.Desc as string type and then if this string contains json object, it may be desirilized again as per future releases
                                string strDesc = (string)infoPl.Desc;
                                break;
                        }
                    }
                }
            }
            Console.Write(result);
            return eInvoice;
        }
    }
}