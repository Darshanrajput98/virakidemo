﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using vb.Data;
using vb.Data.Model;
using vb.Service;
using Microsoft.Reporting.WebForms;
using System.Data;
using System.IO;

namespace vbwebsite.Areas.wholesale.Controllers
{
    public class OrdersController : Controller
    {
        private static object Lock = new object();
        private IOrderService _orderservice;
        private ICommonService _commonservice;
        public long OrderIdvalue;

        List<OrderQtyInvoiceList> Lstdata;
        List<OrderQtyInvoiceList> Lstdatainvoice;

        public OrdersController(IOrderService orderservice, ICommonService commonservice)
        {
            _orderservice = orderservice;
            _commonservice = commonservice;
        }


        //
        // GET: /wholesale/Orders/
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult ManageOrders()
        {
            Session["UserID"] = "1";
            ViewBag.Customer = _orderservice.GetAllCustomerName();
            ViewBag.Product = _orderservice.GetAllProductName();
            return View();
        }


        [HttpPost]
        public ActionResult AddOrder(OrderViewModel data)
        {
            lock (Lock)
            {
                var lstdata = _orderservice.GetLastOrderID();
                string OrderID = "";
                if (lstdata != null)
                {
                    long incr = Convert.ToInt64(lstdata.OrderID + 1);
                    OrderID = "VB" + Convert.ToString(incr);
                }
                else
                {
                    OrderID = "VB1";
                }


                try
                {
                    data.InvoiceNumber = OrderID;
                    data.CreatedBy = Convert.ToInt64(Session["UserID"]);
                    data.CreatedOn = DateTime.UtcNow;
                    data.UpdatedBy = Convert.ToInt64(Session["UserID"]);
                    data.UpdatedOn = DateTime.UtcNow;

                    long respose = _orderservice.AddOrder(data);
                    return Json(respose, JsonRequestBehavior.AllowGet);




                }
                catch (Exception ex)
                {
                    return Json(false, JsonRequestBehavior.AllowGet);
                }
            }

        }

        public ActionResult ViewOrderList()
        {
            Session["UserID"] = "1";
            return View();
        }

        public PartialViewResult ViewOrderList1()
        {
            List<OrderListResponse> objModel = _orderservice.GetAllOrderQtyList();
            return PartialView(objModel);
        }

        [HttpPost]
        public ActionResult GetUnit(long ProductID)
        {
            var lstUnit = _orderservice.GetAutoCompleteProduct(ProductID);
            return Json(lstUnit, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult GetSellPrice(long ProductName, decimal Quantity, string Tax)
        {
            if (Tax != "")
            {
                var SellPrice = _orderservice.GetAutoCompleteSellPrice(ProductName, Quantity, Tax);
                return Json(SellPrice, JsonRequestBehavior.AllowGet);
            }
            else
            {
                GetSellPrice objdata = new GetSellPrice();
                objdata.SellPrice = 0;
                objdata.Tax = 0;
                return Json(objdata, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost]
        public ActionResult GetTaxForCustomer(long CustomerID)
        {
            var Tax = _orderservice.GetTaxForCustomer(CustomerID);
            return Json(Tax, JsonRequestBehavior.AllowGet);
        }

        public ActionResult SearchViewBillWiseOrderList(Int64? id, Int64? custid, Int64? uid, DateTime? txtfrom, DateTime? txtto)
        {
            Session["UserID"] = "1";
            ViewBag.SalesPersonList = _commonservice.GetRoleWiseUserList();
            ViewBag.Customer = _orderservice.GetAllCustomerName();
            //  ViewBag.CustomerList = _commonservice.GetAllCustomerList();
            return View();
        }

        [HttpPost]
        public PartialViewResult ViewBillWiseOrderList(OrderListResponse model)
        {
            if (model.Isclear == true)
            {
                Session["custid"] = "";
                Session["uid"] = "";
                Session["txtfrom"] = "";
                Session["txtto"] = "";
            }
            if (model.From.ToString("MM-dd-yyyy") == "01-01-0001")
            {
                model.From = Convert.ToDateTime(DateTime.Now);
            }
            if (model.To.ToString("MM-dd-yyyy") == "01-01-0001")
            {
                model.To = Convert.ToDateTime(DateTime.Now.AddDays(1));
            }
            List<OrderListResponse> objModel = _orderservice.GetAllBillWiseOrderList(model);
            return PartialView(objModel);
        }

        public ActionResult SearchViewBillWiseCreditMemoList(Int64? id, Int64? custid, Int64? uid, DateTime? txtfrom, DateTime? txtto, Int64? pid)
        {
            Session["UserID"] = "1";
            ViewBag.SalesPersonList = _commonservice.GetRoleWiseUserList();
            ViewBag.Customer = _orderservice.GetAllCustomerName();
            ViewBag.Product = _orderservice.GetAllProductName();
            //  ViewBag.CustomerList = _commonservice.GetAllCustomerList();
            return View();
        }

        [HttpPost]
        public PartialViewResult ViewBillWiseCreditMemoList(ClsReturnOrderListResponse model)
        {
            if (model.Isclear == true)
            {
                Session["ccustid"] = "";
                Session["cuid"] = "";
                Session["ctxtfrom"] = "";
                Session["ctxtto"] = "";
                Session["cpid"] = "";
            }
            if (model.From.ToString("MM-dd-yyyy") == "01-01-0001")
            {
                model.From = Convert.ToDateTime(DateTime.Now);
            }
            if (model.To.ToString("MM-dd-yyyy") == "01-01-0001")
            {
                model.To = Convert.ToDateTime(DateTime.Now.AddDays(1));
            }
            List<ClsReturnOrderListResponse> objModel = _orderservice.GetBillWiseCreditMemoForOrder(model);


            var results = from p in objModel
                          group p.CustomerName by p.InvoiceNumber into g
                          select new { InvoiceNumber = g.Key, Cars = g.ToList() };

            List<ReturnOrderListResponse> objdata = new List<ReturnOrderListResponse>();

            foreach (var item in results)
            {
                ReturnOrderListResponse obj = new ReturnOrderListResponse();
                var data = objModel.Where(x => x.InvoiceNumber == item.InvoiceNumber).FirstOrDefault();
                obj.AreaName = data.AreaName;
                obj.CustomerName = data.CustomerName;
                obj.CreatedOn = data.CreatedOn;
                obj.GrandFinalTotal = data.GrandFinalTotal;
                obj.GrandQuantity = data.GrandQuantity;
                obj.InvoiceNumber = data.InvoiceNumber;
                obj.OrderID = data.OrderID;
                obj.UserName = data.UserName;
                List<OrderQtyList> lstdatanew = new List<OrderQtyList>();
                lstdatanew = objModel.Where(x => x.InvoiceNumber == obj.InvoiceNumber).Select(x => new OrderQtyList() { ProductID = x.ProductID, OrderQtyID = x.OrderQtyID, OrderID = x.OrderID, CategoryTypeID = x.CategoryTypeID, ReturnedQuantity = x.ReturnedQuantity, SerialNumber = x.SerialNumber, ProductName = x.ProductName, Quantity = x.Quantity, UnitName = x.UnitName, ProductPrice = x.ProductPrice, LessAmount = x.LessAmount, SaleRate = x.SaleRate, BillDiscount = x.BillDiscount, Total = x.Total, Tax = x.Tax, TaxAmt = x.TaxAmt, FinalTotal = x.FinalTotal, CustomerID = x.CustomerID }).ToList();
                obj.lstOrderQty = new List<OrderQtyList>();
                obj.lstOrderQty = lstdatanew;
                objdata.Add(obj);
            }

            return PartialView(objdata);
        }

        public ActionResult SearchViewOrderList(Int64? id, Int64? custid, Int64? uid, DateTime? txtfrom, DateTime? txtto)
        {
            Session["UserID"] = "1";
            ViewBag.SalesPersonList = _commonservice.GetRoleWiseUserList();
            ViewBag.Customer = _orderservice.GetAllCustomerName();
            //  ViewBag.CustomerList = _commonservice.GetAllCustomerList();
            return View();
        }

        [HttpPost]
        public PartialViewResult ViewOrderList(OrderListResponse model)
        {
            if (model.Isclear == true)
            {
                Session["custid"] = "";
                Session["uid"] = "";
                Session["txtfrom"] = "";
                Session["txtto"] = "";
            }
            List<OrderListResponse> objModel = _orderservice.GetAllOrderList(model);
            return PartialView(objModel);
        }

        [HttpPost]
        public PartialViewResult ViewReturnedOrderList(OrderListResponse model)
        {
            if (model.Isclear == true)
            {
                Session["custid"] = "";
                //Session["uid"] = "";
                Session["txtfrom"] = "";
                Session["txtto"] = "";
            }
            List<OrderListResponse> objModel = _orderservice.GetAllReturnedOrderList(model);
            return PartialView(objModel);
        }

        public ActionResult SearchInvoice()
        {
            Session["UserID"] = "1";
            //ViewBag.SalesPersonList = _commonservice.GetRoleWiseUserList(4);
            //ViewBag.Customer = _orderservice.GetAllCustomerName();           
            return View();
        }

        [HttpPost]
        public PartialViewResult ViewSearchInvoiceList(OrderListResponse model)
        {
            if (model.Isclear == true)
            {
                Session["custid"] = "";
                Session["uid"] = "";
                Session["txtfrom"] = "";
                Session["txtto"] = "";
            }
            List<OrderListResponse> objModel = _orderservice.GetSearchInvoiceList(model);
            return PartialView(objModel);
        }

        [HttpPost]
        public ActionResult PrintCreditMemo(string CreditMemoNumber)
        {
            //OrderIdvalue = CreditMemoNumber;
            //string CreditMemoNum = "";
            //string[] str = CreditMemoNumber.Split(',');
            //foreach(var item in str)
            //{
            //    if(CreditMemoNum == "")
            //    {
            //        CreditMemoNum = str[0].ToString();
            //    }
            //    else
            //    {
            //        CreditMemoNum = CreditMemoNum + "," + strng[0].ToString();
            //    }
            //}

            LocalReport lr = new LocalReport();
            string path = "";
            if (Request.Url.Host.Contains("localhost"))
            {
                path = "Report/CreditMemoInvoice.rdlc";
            }
            else
            {
                path = Server.MapPath("~/Report/CreditMemoInvoice.rdlc");
            }

            lr.ReportPath = path;


            //var orderdata = _orderservice.GetCreditMemoInvoiceForOrderPrint(OrderID);
            //DataTable header = Common.ToDataTable(orderdata);
            Lstdata = _orderservice.GetCreditMemoInvoiceForOrderItemPrint(CreditMemoNumber);
            //ReportDataSource MedsheetHeader = new ReportDataSource("DataSet1", header);
            Lstdatainvoice = new List<OrderQtyInvoiceList>();
            int i = 1;
            decimal total = 0;
            decimal taxtotal = 0;
            decimal grandtotal = 0;
            string NumberToWord = "";
            int totalnumber = 1;
            int dividerdata = 0;
            int totalcount = 1;
            string invnum = "";
            foreach (var item in Lstdata)
            {
                dividerdata = dividerdata + 1;

                totalcount = Lstdata.Where(x => x.InvoiceNumber == item.InvoiceNumber).Count();
                item.RowNumber = i;
                if (item.RowNumber > 15 || (item.InvoiceNumber != invnum && invnum != ""))
                {
                    i = 1;
                    if (item.RowNumber > 15)
                    {
                        totalnumber = totalnumber + 1;
                    }
                    total = 0;
                    taxtotal = 0;
                    grandtotal = 0;
                    NumberToWord = "";
                    if (item.InvoiceNumber != invnum && invnum != "")
                    {
                        totalnumber = 1;
                        //totalcount = Lstdata.Where(x => x.InvoiceNumber == item.InvoiceNumber).Count();
                    }
                }
                invnum = item.InvoiceNumber;
                item.RowNumber = i;
                item.Totalcount = totalcount;
                item.Totalrecord = totalcount;
                total += item.Total;
                taxtotal += item.TaxAmt;
                grandtotal += item.FinalTotal;
                item.ATotalAmount = Math.Round(total, 2);

                if (item.TaxName == "IGST")
                {
                    item.TotalTax = taxtotal;
                }
                else
                {
                    item.TotalTax = taxtotal / 2;
                }

                if (item.Tax == 0)
                {
                    item.InvoiceTitle = "Bill OF SUPPLY";
                }
                else
                {
                    item.InvoiceTitle = "TAX";
                }

                item.TotalTax = Math.Round(item.TotalTax, 2);
                item.TotalAmount = item.Total + item.TaxAmt;
                item.AGrandTotal += grandtotal;
                item.AGrandTotal = Math.Round(item.AGrandTotal, 2);

                int number = Convert.ToInt32(item.AGrandTotal);
                NumberToWord = NumberToWords(number);
                item.GrandAmtWord = NumberToWord;


                var Gtotal = Math.Round(grandtotal);
                item.GrandTotal = Math.Round(Gtotal, 2);
                if (item.TaxName == "IGST")
                {
                    item.TaxAmt = item.TaxAmt;
                }
                else
                {
                    item.TaxAmt = item.TaxAmt / 2;
                }


                if (item.TaxName == "IGST")
                {
                    item.Tax = decimal.Round(item.Tax, 2, MidpointRounding.AwayFromZero);

                }
                else
                {
                    item.Tax = decimal.Round(item.Tax / 2, 2, MidpointRounding.AwayFromZero);
                }

                item.SaleRate = decimal.Round(item.SaleRate, 2, MidpointRounding.AwayFromZero);
                item.divider = dividerdata;

                item.RowNumber = i;

                item.OrdRowNumber = i;

                item.Totalcount = totalcount;
                if (totalcount > 15 * totalnumber)
                {
                    item.Totalcount = totalcount > 15 * totalnumber ? 15 * totalnumber : 15 * totalnumber - totalcount;
                }
                else
                {
                    if (totalnumber == 1)
                    {
                        item.Totalcount = totalcount;
                    }
                    else
                    {
                        item.Totalcount = totalcount - (15 * (totalnumber - 1));
                    }
                }

                Lstdatainvoice.Add(item);
                i++;
                totalcount++;
            }

            DataTable FoodDT = Common.ToDataTable(Lstdatainvoice);

            ReportDataSource DataRecord = new ReportDataSource("DataSet1", FoodDT);

            //lr.DataSources.Add(MedsheetHeader);

            lr.DataSources.Add(DataRecord);


            string reportType = "pdf";
            string mimeType;
            string encoding;
            string fileNameExtension;

            string deviceInfo =

                "<DeviceInfo>" +
            "  <OutputFormat>" + reportType + "</OutputFormat>" +
            "  <PageWidth>11in</PageWidth>" +
            "  <PageHeight>8.5in</PageHeight>" +
            "  <MarginTop>1cm</MarginTop>" +
            "  <MarginLeft>1cm</MarginLeft>" +
            "  <MarginRight>1cm</MarginRight>" +
            "  <MarginBottom>1cm</MarginBottom>" +
            "</DeviceInfo>";

            Warning[] warnings;
            string[] streams;
            byte[] renderedBytes;

            renderedBytes = lr.Render(
                reportType,
                deviceInfo,
                out mimeType,
                out encoding,
                out fileNameExtension,
                out streams,
                out warnings);

            string name = DateTime.Now.Ticks.ToString() + ".pdf";
            string Pdfpathcreate = Server.MapPath("~/creditmemo/" + name);

            BinaryWriter Writer = null;
            Writer = new BinaryWriter(System.IO.File.OpenWrite(Pdfpathcreate));
            Writer.Write(renderedBytes);
            Writer.Flush();
            Writer.Close();

            string url = "";
            if (Request.Url.Host.Contains("localhost"))
            {
                url = "http://" + Request.Url.Host + ":6551/creditmemo/" + name;
            }
            else
            {
                url = "http://" + Request.Url.Host + "/creditmemo/" + name;
            }

            return Json(url, JsonRequestBehavior.AllowGet);
        }


        [HttpPost]
        public ActionResult PrintInvoice(long InvoiceID, string InvoiceNumber)
        {
            OrderIdvalue = InvoiceID;
            LocalReport lr = new LocalReport();
            string path = "";
            if (Request.Url.Host.Contains("localhost"))
            {
                path = "Report/Invoice.rdlc";
            }
            else
            {
                path = Server.MapPath("~/Report/Invoice.rdlc");
            }

            lr.ReportPath = path;


            var orderdata = _orderservice.GetInvoiceForOrderPrint(InvoiceID);
            DataTable header = Common.ToDataTable(orderdata);

            
            ReportDataSource MedsheetHeader = new ReportDataSource("DataSet1", header);
            Lstdatainvoice = new List<OrderQtyInvoiceList>();
            int dividerdata = 0;
            int ordergroup=0;
            for (int i = 1; i <= 2; i++)
            {
                Lstdata = _orderservice.GetInvoiceForOrderItemPrint(OrderIdvalue, 1, InvoiceNumber);
                // List<OrderQtyInvoiceList> Newdatalast = _orderservice.GetInvoiceForOrderItemPrint(OrderIdvalue, 1);
                var typevalue = "1,2";

                foreach (var Typevalue in typevalue.Split(','))
                {
                    long typevaluel = Convert.ToInt64(Typevalue);
                    string taxtype = "0,5,12,18,28";

                    foreach (var taxvalue in taxtype.Split(','))
                    {
                        int rownumber = 1;
                        int totalnumber = 1;
                        decimal taxper = Convert.ToDecimal(taxvalue);
                        var Foodzero = Lstdata.Where(x => x.Tax == taxper && x.CategoryTypeID == typevaluel).OrderBy(y => y.ProductName).ToList();
                        if (Foodzero.Count > 0)
                        {
                            ordergroup++;

                            decimal total = 0;
                            decimal taxtotal = 0;
                            decimal grandtotal = 0;
                            string NumberToWord = "";
                            dividerdata = dividerdata + 1;
                            foreach (var item in Foodzero)
                            {
                                if (rownumber > 15)
                                {
                                    rownumber = 1;
                                    totalnumber = totalnumber + 1;
                                    total = 0;
                                    taxtotal = 0;
                                    grandtotal = 0;
                                    NumberToWord = "";
                                    ordergroup++;
                                }


                                item.ordergroup = ordergroup;

                                total += item.Total;
                                taxtotal += item.TaxAmt;
                                grandtotal += item.FinalTotal;
                                item.ATotalAmount = total;
                                item.ATotalAmount = Math.Round(item.ATotalAmount, 2);
                                item.Totalrecord = Lstdata.Count;


                                if (item.TaxName == "IGST")
                                {
                                    item.TotalTax = taxtotal;
                                }
                                else
                                {
                                    item.TotalTax = taxtotal / 2;
                                }

                                if (item.Tax == 0)
                                {
                                    item.InvoiceTitle = "BILL OF SUPPLY";
                                }
                                else
                                {
                                    item.InvoiceTitle = "TAX INVOICE";
                                }

                                item.TotalTax = Math.Round(item.TotalTax, 2);
                                item.TotalAmount = item.Total + item.TaxAmt;
                                item.AGrandTotal += grandtotal;
                                item.AGrandTotal = Math.Round(item.AGrandTotal, 2);

                                int number = Convert.ToInt32(item.AGrandTotal);
                                NumberToWord = NumberToWords(number);
                                item.GrandAmtWord = NumberToWord;


                                var Gtotal = Math.Round(grandtotal);
                                item.GrandTotal = Math.Round(Gtotal, 2);
                                if (item.TaxName == "IGST")
                                {
                                    item.TaxAmt = item.TaxAmt;
                                }
                                else
                                {
                                    item.TaxAmt = item.TaxAmt / 2;
                                }


                                if (item.TaxName == "IGST")
                                {
                                    item.Tax = decimal.Round(item.Tax, 2, MidpointRounding.AwayFromZero);

                                }
                                else
                                {
                                    item.Tax = decimal.Round(item.Tax / 2, 2, MidpointRounding.AwayFromZero);
                                }

                                item.SaleRate = decimal.Round(item.SaleRate, 2, MidpointRounding.AwayFromZero);
                                item.divider = dividerdata;

                                item.RowNumber = rownumber;

                                item.OrdRowNumber = rownumber;

                                item.Totalcount = Foodzero.Count;
                                if (Foodzero.Count > 15 * totalnumber)
                                {
                                    item.Totalcount = Foodzero.Count > 15 * totalnumber ? 15 * totalnumber : 15 * totalnumber - Foodzero.Count;
                                }
                                else
                                {
                                    if (totalnumber == 1)
                                    {
                                        item.Totalcount = Foodzero.Count;
                                    }
                                    else
                                    {
                                        item.Totalcount = Foodzero.Count - (15 * (totalnumber - 1));
                                    }
                                }
                                Lstdatainvoice.Add(item);

                                rownumber = rownumber + 1;
                            }

                        }
                    }
                }
            }
            DataTable FoodDT = Common.ToDataTable(Lstdatainvoice);

            ReportDataSource DataRecord = new ReportDataSource("DataSet2", FoodDT);

            lr.DataSources.Add(MedsheetHeader);

            lr.DataSources.Add(DataRecord);


            string reportType = "pdf";
            string mimeType;
            string encoding;
            string fileNameExtension;

            string deviceInfo =

                "<DeviceInfo>" +
            "  <OutputFormat>" + reportType + "</OutputFormat>" +
            "  <PageWidth>11in</PageWidth>" +
            "  <PageHeight>8.5in</PageHeight>" +
            "  <MarginTop>1cm</MarginTop>" +
            "  <MarginLeft>1cm</MarginLeft>" +
            "  <MarginRight>1cm</MarginRight>" +
            "  <MarginBottom>1cm</MarginBottom>" +
            "</DeviceInfo>";

            Warning[] warnings;
            string[] streams;
            byte[] renderedBytes;

            renderedBytes = lr.Render(
                reportType,
                deviceInfo,
                out mimeType,
                out encoding,
                out fileNameExtension,
                out streams,
                out warnings);

            string name = DateTime.Now.Ticks.ToString() + ".pdf";
            string Pdfpathcreate = Server.MapPath("~/bill/" + name);

            BinaryWriter Writer = null;
            Writer = new BinaryWriter(System.IO.File.OpenWrite(Pdfpathcreate));
            Writer.Write(renderedBytes);
            Writer.Flush();
            Writer.Close();

            string url = "";
            if (Request.Url.Host.Contains("localhost"))
            {
                url = "http://" + Request.Url.Host + ":6551/bill/" + name;
            }
            else
            {
                url = "http://" + Request.Url.Host + "/bill/" + name;
            }

            return Json(url, JsonRequestBehavior.AllowGet);
        }


        public string NumberToWords(int number)
        {
            if (number == 0)
                return "zero";

            if (number < 0)
                return "minus " + NumberToWords(Math.Abs(number));

            string words = "";



            //if ((number / 1000000000) > 0)
            //{
            //    words += NumberToWords(number / 1000000000) + " billion  ";
            //    number %= 1000000000;
            //}


            if ((number / 10000000) > 0)
            {
                words += NumberToWords(number / 10000000) + " Crore ";
                number %= 10000000;
            }


            if ((number / 100000) > 0)
            {
                words += NumberToWords(number / 100000) + " Lakhs ";
                number %= 100000;
            }


            if ((number / 1000) > 0)
            {
                words += NumberToWords(number / 1000) + " Thousand ";
                number %= 1000;
            }

            if ((number / 100) > 0)
            {
                words += NumberToWords(number / 100) + " Hundred ";
                number %= 100;
            }

            if (number > 0)
            {
                if (words != "")
                    words += "and ";

                var unitsMap = new[] { "Zero", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen" };
                var tensMap = new[] { "Zero", "Ten", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety" };

                if (number < 20)
                    words += unitsMap[number];
                else
                {
                    words += tensMap[number / 10];
                    if ((number % 10) > 0)
                        words += "-" + unitsMap[number % 10];
                }
            }

            return words;
        }

        [HttpGet]
        public ActionResult ViewBillWiseInvoice(string invid, Int64? custid, Int64? uid, string txtfrom, string txtto)
        {
            Session["UserID"] = "1";
            Session["custid"] = custid;
            Session["uid"] = uid;
            Session["txtfrom"] = txtfrom;
            Session["txtto"] = txtto;
            if (!string.IsNullOrEmpty(invid))
            {
                List<OrderQtyList> objModel = _orderservice.GetBillWiseInvoiceForOrder(invid);
                return View(objModel);
            }
            else
            {
                return View();
            }
        }

        [HttpGet]
        public ActionResult ViewInvoice(Int64? id, Int64? custid, Int64? uid, string txtfrom, string txtto)
        {
            Session["UserID"] = "1";
            Session["custid"] = custid;
            Session["uid"] = uid;
            Session["txtfrom"] = txtfrom;
            Session["txtto"] = txtto;

            List<OrderQtyList> objModel = _orderservice.GetInvoiceForOrder(Convert.ToInt64(id));
            return View(objModel);
        }

        [HttpGet]
        public ActionResult ViewCreditMemoInvoice(Int64? id, Int64? custid, string txtfrom, string txtto)
        {
            Session["UserID"] = "1";
            Session["custid"] = custid;
            //Session["uid"] = uid;
            Session["txtfrom"] = txtfrom;
            Session["txtto"] = txtto;

            List<OrderQtyList> objModel = _orderservice.GetCreditMemoInvoiceForOrder(Convert.ToInt64(id));
            return View(objModel);
        }

        //[HttpGet]
        //public ActionResult ViewBillWiseCreditMemoInvoice(string id, Int64? custid, Int64? uid, string txtfrom, string txtto)
        //{
        //    Session["UserID"] = "1";
        //    Session["custid"] = custid;
        //    Session["uid"] = uid;
        //    Session["txtfrom"] = txtfrom;
        //    Session["txtto"] = txtto;

        //    List<OrderQtyList> objModel = _orderservice.GetBillWiseCreditMemoInvoiceForOrder(id);
        //    return View(objModel);
        //}

        //[HttpGet]
        //public ActionResult ViewBillWiseCreditMemo(string invid, Int64? custid, Int64? uid, string txtfrom, string txtto)
        //{
        //    Session["UserID"] = "1";
        //    Session["ccustid"] = custid;
        //    Session["cuid"] = uid;
        //    Session["ctxtfrom"] = txtfrom;
        //    Session["ctxtto"] = txtto;
        //    if (!string.IsNullOrEmpty(invid))
        //    {
        //        List<OrderQtyList> objModel = _orderservice.GetBillWiseCreditMemoForOrder(invid);
        //        return View(objModel);
        //    }
        //    else
        //    {
        //        return View();
        //    }
        //}

        [HttpGet]
        public ActionResult ViewCreditMemo(Int64? id, Int64? custid, Int64? uid, string txtfrom, string txtto)
        {
            Session["UserID"] = "1";
            Session["custid"] = custid;
            Session["uid"] = uid;
            Session["txtfrom"] = txtfrom;
            Session["txtto"] = txtto;

            List<OrderQtyList> objModel = _orderservice.GetCreditMemoForOrder(Convert.ToInt64(id));
            return View(objModel);
        }

        [HttpPost]
        public JsonResult CreateMemo(List<OrderQtyList> data)
        {
            string objModel = _orderservice.CreateCreditMemo(data);
            return Json(objModel, JsonRequestBehavior.AllowGet);
        }



        public ActionResult CreditMemoPrint(Int64? id, Int64? custid, DateTime? txtfrom, DateTime? txtto)
        {
            Session["UserID"] = "1";
            ViewBag.SalesPersonList = _commonservice.GetRoleWiseUserList();
            ViewBag.Customer = _orderservice.GetAllCustomerName();
            return View();
        }



    }

    public class GetSellPrice
    {
        public decimal SellPrice { get; set; }
        public decimal Tax { get; set; }
    }







}