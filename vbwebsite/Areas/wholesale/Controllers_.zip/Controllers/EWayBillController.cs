﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using vb.Service;
using TaxProEWB.API;
using vb.Data;
using System.Configuration;
using System.Security.Cryptography;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace vbwebsite.Areas.wholesale.Controllers
{
    public class EWayBillController : Controller
    {
        private static object Lock = new object();
        private IEWayBillService _EWayservice;
        public EWBSession EwbSession = new EWBSession();

        public EWayBillController(IEWayBillService eWayservice)
        {
            _EWayservice = eWayservice;
        }

        public EWayBillController()
        {
            // TODO: Complete member initialization
        }

        // GET: /wholesale/EWayBill/
        public ActionResult Index()
        {
            SaveSettings();
            SaveLoginDetails();
            return View();
        }

        public void SaveSettings()
        {
            EwbSession.EwbApiSetting.GSPName = "";
            EwbSession.EwbApiSetting.AspUserId = "1655841121";
            EwbSession.EwbApiSetting.AspPassword = "M@tizS0ft";
            EwbSession.EwbApiSetting.EWBClientId = "";
            EwbSession.EwbApiSetting.EWBClientSecret = "";
            EwbSession.EwbApiSetting.EWBGSPUserID = "";
            EwbSession.EwbApiSetting.BaseUrl = "https://einvapi.charteredinfo.com";
            // EwbSession.EwbApiSetting.AspUrl = txtAspUrl.Text;
            Shared.SaveAPISetting(EwbSession.EwbApiSetting);
        }

        public void SaveLoginDetails()
        {
            EwbSession.EwbApiLoginDetails.EwbGstin = "34AACCC1596Q002";
            EwbSession.EwbApiLoginDetails.EwbUserID = ConfigurationManager.AppSettings["UserName"];
            EwbSession.EwbApiLoginDetails.EwbPassword = ConfigurationManager.AppSettings["Password"];
            EwbSession.EwbApiLoginDetails.EwbAppKey = ConfigurationManager.AppSettings["EWBAppKey"];
            EwbSession.EwbApiLoginDetails.EwbAuthToken = EwbSession.EwbApiLoginDetails.EwbAuthToken;
            EwbSession.EwbApiLoginDetails.EwbTokenExp = EwbSession.EwbApiLoginDetails.EwbTokenExp;
            EwbSession.EwbApiLoginDetails.EwbSEK = EwbSession.EwbApiLoginDetails.EwbSEK;
            Shared.SaveAPILoginDetails(EwbSession.EwbApiLoginDetails);
        }

        // encrypting the password using the public key given by the E-way bill System


        // generate appkey
        public static byte[] generateSecureKey()
        {
            Aes KEYGEN = Aes.Create();
            byte[] secretKey = KEYGEN.Key;
            return secretKey;
        }

        // encrypting the appkey using the public key given by the E-way bill System


        public string GetAuthToken()
        {
            string AuthTokenResponse = string.Empty;
            TxnRespWithObjAndInfo<EWBSession> TxnResp = Task.Run(() => EWBAPI.GetAuthTokenAsync(EwbSession)).Result;
            // here store in DB
            return AuthTokenResponse;
        }

        //public static void GenEWB(List<EwayBillList> orderData, List<EwayBillItemList> lstData)
        //{
        //    EWayBillController EwayBill = new EWayBillController();
        //    EwayBill.GenerateEWB();
        //}

        [HttpPost]
        public ActionResult GenerateEWB(long orderId, long godownId = 1, long transportId = 1)
        {

            //string strJson = File.ReadAllText(@"C:\Users\Pallavi\Desktop\new28.txt");

            List<EwayBillList> orderData = _EWayservice.GetEWayBill(orderId, godownId, transportId);
            List<EwayBillItemList> lstData = _EWayservice.GetEWayBillItemList(orderId);


            ReqGenEwbPl ewbGen = new ReqGenEwbPl();
            foreach (var item in orderData)
            {
                ewbGen.supplyType = item.SupplyType;
                ewbGen.subSupplyType = item.SubType;
                ewbGen.subSupplyDesc = "";
                ewbGen.docType = item.DocType;
                ewbGen.docNo = item.DocNo;
                ewbGen.docDate = item.DocDate;
                ewbGen.fromGstin = item.From_GSTIN;//"07AACCC1596Q1Z4";
                ewbGen.fromTrdName = item.From_OtherPartyName;
                ewbGen.fromAddr1 = item.From_Address1;
                ewbGen.fromAddr2 = item.From_Address2;
                ewbGen.fromPlace = item.From_Place;
                ewbGen.fromPincode = Convert.ToInt32(item.From_PinCode);//263652;/*110001;*/
                ewbGen.fromStateCode = 0;
                ewbGen.actFromStateCode = 32;
                ewbGen.toGstin = item.To_GSTIN;
                ewbGen.toTrdName = item.To_OtherPartyName;
                ewbGen.toAddr1 = item.To_Address1;
                ewbGen.toAddr2 = item.To_Address2;
                ewbGen.toPlace = item.To_Place;
                ewbGen.toPincode = Convert.ToInt32(item.To_PinCode);/*110005;*/
                ewbGen.toStateCode = 05;
                ewbGen.actToStateCode = 05;
                ewbGen.transactionType = Convert.ToInt32(item.Transaction_Type);
                ewbGen.dispatchFromGSTIN = ""; /*29AAAAA1303P1ZV*/
                ewbGen.dispatchFromTradeName = "";
                ewbGen.shipToGSTIN = ""; //29ALSPR1722R1Z3
                ewbGen.shipToTradeName = "";
                ewbGen.otherValue = -100;
                ewbGen.totalValue = item.FinalTotal;
                ewbGen.cgstValue = 0;
                ewbGen.sgstValue = 0;
                ewbGen.igstValue = 0;
                ewbGen.cessValue = 0;
                ewbGen.cessNonAdvolValue = 400;
                ewbGen.transporterId = item.TransID;
                ewbGen.transporterName = item.TransName;
                ewbGen.transDocNo = item.TransDocNo;
                ewbGen.totInvValue = 0;
                ewbGen.transMode = item.TransMode;//1
                ewbGen.transDistance = item.DistanceKM.ToString(); /*1200*/
                ewbGen.transDocDate = item.TransDate;
                ewbGen.vehicleNo = item.VehicleNo;//PVC1234
                ewbGen.vehicleType = item.VehicleType;//R
                ewbGen.itemList = new List<ReqGenEwbPl.ItemListInReqEWBpl>();
                ///data from database of perticular id
                foreach (EwayBillItemList itm in lstData)
                {
                    ewbGen.itemList.Add(new ReqGenEwbPl.ItemListInReqEWBpl() { productName = itm.Product, productDesc = itm.Description, cessNonAdvol = Convert.ToDouble(itm.Cess_Non_Advol_Amount), cessRate = Convert.ToInt32(itm.CESSTaxRate), cgstRate = Convert.ToInt32(itm.CGSTTaxRate), hsnCode = Convert.ToInt32(itm.HSN), igstRate = Convert.ToInt32(itm.IGSTTaxRate), qtyUnit = itm.Unit, quantity = Convert.ToDouble(itm.Qty), sgstRate = Convert.ToInt32(itm.SGSTTaxRate), taxableAmount = Convert.ToDouble(itm.TaxAmount) });
                }
                //ewbGen.itemList = EWBItems.ToList();

                //foreach (ReqGenEwbPl.ItemListInReqEWBpl item in EWBItems)
                //{

                //    item.productName;
                //}
            }

            string a = JsonConvert.SerializeObject(ewbGen);
            string result = string.Empty;
            TxnRespWithObjAndInfo<RespGenEwbPl> TxnResp = Task.Run(() => EWBAPI.GenEWBAsync(EwbSession, ewbGen)).Result;
            if (TxnResp.IsSuccess)
                result = JsonConvert.SerializeObject(TxnResp.RespObj);

            //else
            //{

            //    rtbResponce.Text = TxnResp.TxnOutcome;
            ////Check for error "The distance between the pincodes given is too high"



            //    if (TxnResp.TxnOutcome.Contains("702") && !string.IsNullOrEmpty(TxnResp.Info))
            //    {
            //        RespInfoPl respInfoPl = new RespInfoPl();

            //        respInfoPl = JsonConvert.DeserializeObject<RespInfoPl>(TxnResp.Info);
            //        //You can retrive respInfoPl attributes here
            //        ewbGen.transDistance = respInfoPl.distance;
            //        //Call GenEWB API again
            //        TxnResp = Task.Run(() => EWBAPI.GenEWBAsync(EwbSession, ewbGen)).Result;
            //        //if (TxnResp.IsSuccess)
            //        //    rtbResponce.Text = JsonConvert.SerializeObject(TxnResp.RespObj);
            //        //else
            //        //    rtbResponce.Text = TxnResp.TxnOutcome;
            //    }

            //}

            return Json(result, JsonRequestBehavior.AllowGet);

        }

        //[HttpGet]
        //public ActionResult GetEWBDetails(string EwbNo)
        //{
        //    TxnRespWithObj<RespGetEWBDetail> TxnResp = Task.Run(() => EWBAPI.GetEWBDetailAsync(EwbSession, EwbNo)).Result;
        //    string result = string.Empty;
        //    if (TxnResp.IsSuccess)
        //        result = JsonConvert.SerializeObject(TxnResp.RespObj);
        //    else
        //        result = TxnResp.TxnOutcome;
        //}
    }
}